# CloudCord Plus 1.0.0

Plugin para o CloudCord (formato Bunny/CloudCord). **Não altera o APK** – o CloudCord carrega
a lógica dele de um JS remoto, então a versão "Plus" entra como plugin.

## Instalar (3 passos)
1. Crie um repositório PÚBLICO no seu GitHub (ex.: `cloudcord-plus`) e suba **estes arquivos mantendo as pastas**:
   - `repo.json`
   - `builds/cloudcord-plus/index.js`
   - `builds/cloudcord-plus/manifest.json`
2. No CloudCord: **Plugins → Repositórios → Adicionar** e cole:
   `https://raw.githubusercontent.com/SEU_USUARIO/cloudcord-plus/main/repo.json`
3. Instale **CloudCord Plus**, ative e reabra o app.

## Usar plugins BetterDiscord
- Comando: `/bd-install https://raw.githubusercontent.com/.../Plugin.plugin.js`
- Ou: Configurações do CloudCord Plus → colar o link → "Instalar plugin BD".
- `/bd-list`, `/bd-toggle nome`, `/bd-remove nome`.

## Acesso por usuário
Edite o topo do `index.js`:
```js
const ACCESS = { tester: ["velky_testes"], owner: ["xohus"] };
```
Aceita username (minúsculo) ou ID. `owner` herda tudo de `tester`.
**O `"xohus"` é um palpite (handle do GitHub do dono) – troque pelo @ real dele no Discord.**
Isso é controle client-side: decide o que aparece no SEU app, não é segurança.

## Adicionar mais features
Cada feature é 1 chamada em `index.js`:
```js
addCmdFeature({ id: "hello", name: "/hello", desc: "Diz oi", group: "Diversão",
  options: [], run: () => "oi!" });
```
Use `tier: "tester"` ou `"owner"` para restringir.

## Limites conhecidos
- Testado só em ambiente simulado (Node), NÃO em celular.
- BD ≠ mobile: plugins que mexem em DOM/CSS/Electron/`fs` ou dependem de ZeresPluginLibrary/BDFDB não funcionam.
- `BdApi.Webpack.getModule(filtro)` só enxerga módulos já inicializados do Metro.
